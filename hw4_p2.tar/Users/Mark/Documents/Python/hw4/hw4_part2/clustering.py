''' Marcus Barnes
    mbb11d



This program demostrates clustering on the iris dataset
    The iris dataset is a dataset about 3 kinds of iris flowers, with 4 features
    per flower.
    Clustering is a type of machine learning where there is no idea of the ground
    truth. Instead, data points are grouped as "similar" based on how close
    they are to each other.

    The sklearn library contains a lot of functions for machine learning,
    including clustering '''

import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.cluster import KMeans
import sklearn.metrics as sm

import pandas as pd
import numpy as np

from sklearn.decomposition import PCA #needed for setting components


digits = datasets.load_digits(n_class=10)  #load the digits

x,y = pd.DataFrame(digits.data), pd.DataFrame(digits.target)
a = pd.DataFrame(data = PCA(n_components = 2).fit_transform(x,y), columns=['COL1','COL2']) #WTF, this took forevery
model = KMeans(n_clusters=10)   #split in 10 classes
model.fit(x)
plt.figure(figsize=(14,7))
colormap = np.array(['red', 'yellow', 'black', 'purple','silver','lightblue','darkblue', 'brown', 'orange', 'green'])
#plt.subplot(1, 2, 2)
plt.scatter(a.COL1, a.COL2, c=colormap[model.labels_], s=40)
plt.title( 'K Means Classification of the digits dataset' )
plt.show()